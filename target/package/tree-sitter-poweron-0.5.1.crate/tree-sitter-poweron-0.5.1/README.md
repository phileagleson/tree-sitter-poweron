# @phileagleson/treesitter-poweron

## About this project   

This is a [tree-sitter](https://tree-sitter.github.io/tree-sitter/) grammar for the PowerOn Programming Language.
While there are still a couple issues it is pretty complete and will parse most poweron files without issues. 
PR's Welcome.
---
  
### Screenshot
![Neovim Poweron Sreenshon](images/screenshot.png)

(The tree-sitter map on the side is created using [Nvim Tree-sitter Playground](https://github.com/nvim-treesitter/playground))
